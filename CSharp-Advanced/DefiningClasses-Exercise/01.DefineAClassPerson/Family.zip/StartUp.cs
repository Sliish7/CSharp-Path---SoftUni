﻿namespace DefiningClasses
{
    public class StartUp
    {
        static void Main()
        {
            Family family = new();
            int familyCount = int.Parse(Console.ReadLine());

            for (int i = 0; i < familyCount; i++)
            {
                string[] personProps = Console.ReadLine()
                    .Split(" ");

                Person person = new(personProps[0], int.Parse(personProps[1]));
                family.AddMember(person);
            }

            Person oldest = family.GetOldestMember();
            Console.WriteLine($"{oldest.Name} {oldest.Age}");
        }
    }
}